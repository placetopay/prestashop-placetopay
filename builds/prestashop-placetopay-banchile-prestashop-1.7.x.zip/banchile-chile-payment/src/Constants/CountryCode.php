<?php

namespace BanchileChile\Constants;

use BanchileChile\Countries\ChileCountryConfig;
use BanchileChile\Countries\ColombiaCountryConfig;
use BanchileChile\Countries\CountryConfig;

/**
 * @see https://en.wikipedia.org/wiki/List_of_ISO_3166_country_codes
 */
interface CountryCode
{
    public const CHILE = 'CL';

    public const URUGUAY = 'UY';
}
