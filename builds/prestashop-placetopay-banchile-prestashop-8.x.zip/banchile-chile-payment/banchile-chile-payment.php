<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once 'spl_autoload.php';

class BanchileChilePayment extends BanchileChile\Models\PlacetoPayPaymentBanchileChile
{
}
