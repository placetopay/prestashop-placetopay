<?php

namespace BanchileChile\Constants;

/**
 * Interface Environment
 */
interface Environment
{
    /**
     * Environment Production
     */
    const PRODUCTION = 'PRODUCTION';

    /**
     * Environment Test
     */
    const TEST = 'TEST';

    /**
     * Environment Development
     */
    const DEVELOPMENT = 'DEVELOPMENT';

    /**
     * Environment Custom
     */
    const CUSTOM = 'CUSTOM';
}
